// NCK WEALTH — Google Sheets lead capture
// 1) Create a Google Sheet and copy its ID from the URL.
// 2) Replace SPREADSHEET_ID below.
// 3) Deploy as Web app: Execute as Me, Who has access: Anyone.
// 4) Put the Web App URL into contact-handler.php ($sheetWebhook).
const SPREADSHEET_ID = 'PASTE_YOUR_GOOGLE_SHEET_ID_HERE';
const SHEET_NAME = 'Leads';

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents || '{}');
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    let sh = ss.getSheetByName(SHEET_NAME) || ss.insertSheet(SHEET_NAME);
    if (sh.getLastRow() === 0) sh.appendRow(['Timestamp','Name','Mobile','Email','City','Interested In','Message','Source']);
    sh.appendRow([new Date(), data.name||'', data.mobile||'', data.email||'', data.city||'', data.interested_in||'', data.message||'', data.source||'nckwealth.com']);
    return ContentService.createTextOutput(JSON.stringify({ok:true})).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ok:false,error:String(err)})).setMimeType(ContentService.MimeType.JSON);
  }
}
